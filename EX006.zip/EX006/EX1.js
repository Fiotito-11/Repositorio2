const http = require('http');
const request = require('request');

http.createServer((req, res) => {
   request('https://apipheny.io/free-api/#apis-without-key', (error, response, body) => {
    console.log(body);
   });

}).listen(8080);

//GABRIEL DE SOUZA 5933253668